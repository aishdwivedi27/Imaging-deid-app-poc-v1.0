# Double-click alternative: right-click > Run with PowerShell
Set-Location -Path $PSScriptRoot
if (Get-Command py -ErrorAction SilentlyContinue) { py serve_ohif.py } else { python serve_ohif.py }
