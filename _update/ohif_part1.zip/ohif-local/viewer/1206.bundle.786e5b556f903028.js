"use strict";
(globalThis["rspackChunk"] = globalThis["rspackChunk"] || []).push([[1206], {
77333(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var react__rspack_import_0 = __webpack_require__(86326);
/* import */ var prop_types__rspack_import_1 = __webpack_require__(97598);
/* import */ var prop_types__rspack_import_1_default = /*#__PURE__*/__webpack_require__.n(prop_types__rspack_import_1);
/* import */ var _ohif_ui_next__rspack_import_2 = __webpack_require__(85505);
/* import */ var _ohif_extension_cornerstone__rspack_import_3 = __webpack_require__(75609);
/* import */ var _cornerstonejs_tools__rspack_import_4 = __webpack_require__(55526);
/* import */ var _getContextModule__rspack_import_5 = __webpack_require__(28835);
/* import */ var _cornerstonejs_core__rspack_import_6 = __webpack_require__(88479);
/* import */ var _ohif_core__rspack_import_7 = __webpack_require__(50679);
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }








function TrackedCornerstoneViewport(props) {
  const {
    servicesManager
  } = (0,_ohif_core__rspack_import_7/* .useSystem */.Jg)();
  const {
    displaySets,
    viewportId
  } = props;
  const {
    measurementService,
    cornerstoneViewportService,
    viewportGridService,
    toolbarService
  } = servicesManager.services;

  // Todo: handling more than one displaySet on the same viewport
  const displaySet = displaySets[0];
  const [trackedMeasurements, sendTrackedMeasurementsEvent] = (0,_getContextModule__rspack_import_5/* .useTrackedMeasurements */.B)();
  const [isTracked, setIsTracked] = (0,react__rspack_import_0.useState)(false);
  const [trackedMeasurementUID, setTrackedMeasurementUID] = (0,react__rspack_import_0.useState)(null);
  const [viewportElem, setViewportElem] = (0,react__rspack_import_0.useState)(null);
  const {
    trackedSeries
  } = trackedMeasurements.context;
  const {
    SeriesInstanceUID
  } = displaySet;
  const updateIsTracked = (0,react__rspack_import_0.useCallback)(() => {
    if (trackedSeries.includes(SeriesInstanceUID) !== isTracked) {
      setIsTracked(!isTracked);
    }
  }, [isTracked, SeriesInstanceUID, trackedSeries]);
  const onElementEnabled = (0,react__rspack_import_0.useCallback)(evt => {
    if (evt.detail.element !== viewportElem) {
      // The VOLUME_VIEWPORT_NEW_VOLUME event allows updateIsTracked to reliably fetch the image id for a volume viewport.
      evt.detail.element?.addEventListener(_cornerstonejs_core__rspack_import_6.Enums.Events.VOLUME_VIEWPORT_NEW_VOLUME, updateIsTracked);
      setViewportElem(evt.detail.element);
    }
  }, [updateIsTracked, viewportElem]);
  const onElementDisabled = (0,react__rspack_import_0.useCallback)(() => {
    viewportElem?.removeEventListener(_cornerstonejs_core__rspack_import_6.Enums.Events.VOLUME_VIEWPORT_NEW_VOLUME, updateIsTracked);
  }, [updateIsTracked, viewportElem]);
  (0,react__rspack_import_0.useEffect)(updateIsTracked, [updateIsTracked]);
  (0,react__rspack_import_0.useEffect)(() => {
    const {
      unsubscribe
    } = cornerstoneViewportService.subscribe(cornerstoneViewportService.EVENTS.VIEWPORT_DATA_CHANGED, props => {
      if (props.viewportId !== viewportId) {
        return;
      }
      updateIsTracked();
    });
    return () => {
      unsubscribe();
    };
  }, [updateIsTracked, viewportId]);
  (0,react__rspack_import_0.useEffect)(() => {
    if (isTracked) {
      _cornerstonejs_tools__rspack_import_4.annotation.config.style.setViewportToolStyles(viewportId, {
        ReferenceLines: {
          lineDash: '4,4'
        },
        global: {
          lineDash: ''
        }
      });
      cornerstoneViewportService.getRenderingEngine().renderViewport(viewportId);
      return;
    }
    _cornerstonejs_tools__rspack_import_4.annotation.config.style.setViewportToolStyles(viewportId, {
      global: {
        lineDash: '4,4'
      }
    });
    cornerstoneViewportService.getRenderingEngine().renderViewport(viewportId);
    return () => {
      _cornerstonejs_tools__rspack_import_4.annotation.config.style.setViewportToolStyles(viewportId, {});
    };
  }, [isTracked]);

  /**
   * The effect for listening to measurement service measurement added events
   * and in turn firing an event to update the measurement tracking state machine.
   * The TrackedCornerstoneViewport is the best place for this because when
   * a measurement is added, at least one TrackedCornerstoneViewport will be in
   * the DOM and thus can react to the events fired.
   */
  (0,react__rspack_import_0.useEffect)(() => {
    const added = measurementService.EVENTS.MEASUREMENT_ADDED;
    const addedRaw = measurementService.EVENTS.RAW_MEASUREMENT_ADDED;
    const subscriptions = [];
    [added, addedRaw].forEach(evt => {
      subscriptions.push(measurementService.subscribe(evt, ({
        source,
        measurement
      }) => {
        const {
          activeViewportId
        } = viewportGridService.getState();

        // Each TrackedCornerstoneViewport receives the MeasurementService's events.
        // Only send the tracked measurements event for the active viewport to avoid
        // sending it more than once.
        if (viewportId === activeViewportId) {
          const {
            referenceStudyUID: StudyInstanceUID,
            referenceSeriesUID: SeriesInstanceUID,
            uid: measurementId,
            toolName
          } = measurement;
          sendTrackedMeasurementsEvent('SET_DIRTY', {
            SeriesInstanceUID
          });
          sendTrackedMeasurementsEvent('TRACK_SERIES', {
            viewportId,
            StudyInstanceUID,
            SeriesInstanceUID,
            measurementId,
            toolName
          });
        }
      }).unsubscribe);
    });
    return () => {
      subscriptions.forEach(unsub => {
        unsub();
      });
    };
  }, [measurementService, sendTrackedMeasurementsEvent, viewportId, viewportGridService]);
  const switchMeasurement = (0,react__rspack_import_0.useCallback)(direction => {
    const newTrackedMeasurementUID = _getNextMeasurementUID(direction, servicesManager, trackedMeasurementUID, trackedMeasurements);
    if (!newTrackedMeasurementUID) {
      return;
    }
    setTrackedMeasurementUID(newTrackedMeasurementUID);
    measurementService.jumpToMeasurement(viewportId, newTrackedMeasurementUID);
  }, [measurementService, servicesManager, trackedMeasurementUID, trackedMeasurements, viewportId]);
  const getCornerstoneViewport = () => {
    return /*#__PURE__*/react__rspack_import_0.createElement(_ohif_extension_cornerstone__rspack_import_3/* .OHIFCornerstoneViewport */.R9, _extends({}, props, {
      onElementEnabled: evt => {
        props.onElementEnabled?.(evt);
        onElementEnabled(evt);
      },
      onElementDisabled: onElementDisabled
    }));
  };
  return /*#__PURE__*/react__rspack_import_0.createElement("div", {
    className: "relative flex h-full w-full flex-row overflow-hidden"
  }, getCornerstoneViewport());
}
TrackedCornerstoneViewport.propTypes = {
  displaySets: prop_types__rspack_import_1_default().arrayOf((prop_types__rspack_import_1_default().object.isRequired)).isRequired,
  viewportId: (prop_types__rspack_import_1_default().string.isRequired),
  dataSource: (prop_types__rspack_import_1_default().object),
  children: (prop_types__rspack_import_1_default().node)
};
function _getNextMeasurementUID(direction, servicesManager, trackedMeasurementId, trackedMeasurements) {
  const {
    measurementService,
    viewportGridService
  } = servicesManager.services;
  const measurements = measurementService.getMeasurements();
  const {
    activeViewportId,
    viewports
  } = viewportGridService.getState();
  const {
    displaySetInstanceUIDs: activeViewportDisplaySetInstanceUIDs
  } = viewports.get(activeViewportId);
  const {
    trackedSeries
  } = trackedMeasurements.context;

  // Get the potentially trackable measurements for the series of the
  // active viewport.
  // The measurements to jump between are the same
  // regardless if this series is tracked or not.

  const filteredMeasurements = measurements.filter(m => trackedSeries.includes(m.referenceSeriesUID) && activeViewportDisplaySetInstanceUIDs.includes(m.displaySetInstanceUID));
  if (!filteredMeasurements.length) {
    // No measurements on this series.
    return;
  }
  const measurementCount = filteredMeasurements.length;
  const uids = filteredMeasurements.map(fm => fm.uid);
  let measurementIndex = uids.findIndex(uid => uid === trackedMeasurementId);
  if (measurementIndex === -1) {
    // Not tracking a measurement, or previous measurement now deleted, revert to 0.
    measurementIndex = 0;
  } else {
    measurementIndex += direction;
    if (measurementIndex < 0) {
      measurementIndex = measurementCount - 1;
    } else if (measurementIndex === measurementCount) {
      measurementIndex = 0;
    }
  }
  const newTrackedMeasurementId = uids[measurementIndex];
  return newTrackedMeasurementId;
}
const _getArrowsComponent = (isTracked, switchMeasurement, isActiveViewport) => {
  if (!isTracked) {
    return null;
  }
  return /*#__PURE__*/React.createElement(ViewportActionArrows, {
    onArrowsClick: direction => switchMeasurement(direction),
    className: isActiveViewport ? 'visible' : 'invisible group-hover/pane:visible'
  });
};
/* export default */ const __rspack_default_export = (TrackedCornerstoneViewport);

},

}]);