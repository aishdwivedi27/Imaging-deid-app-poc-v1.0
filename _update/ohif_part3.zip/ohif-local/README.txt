OHIF Viewer - local / offline copy (v3.13.10, MIT licence, see viewer/OHIF_LICENSE.txt)

Needs: Python 3 (any recent version). Chrome or Edge recommended.

Start
  Windows (PowerShell):   cd <this folder> ; py serve_ohif.py      (or right-click start_ohif_windows.ps1 > Run with PowerShell)
  Mac / Linux (bash):     cd <this folder> && python3 serve_ohif.py (or ./start_ohif_mac_linux.sh)

The browser opens http://localhost:3000/local
  1. Drag the .dcm file(s) onto the page (or click "Load files").
  2. Click the study row, then "Basic Viewer".
  3. Annotate with the toolbar: Measurement tools (ruler dropdown) include Rectangle, Ellipse, Freehand/Spline ROI and Arrow.
  4. Open the right-hand "Measurements" panel to label each annotation, then "Export CSV" or
     "Create Report" (saves the annotations as a DICOM SR file).

Stop: press Ctrl+C in the terminal window.
Port busy? Use another:  py serve_ohif.py 3001   /   python3 serve_ohif.py 3001

Privacy: the viewer runs on this computer only (127.0.0.1). Opened files are read inside the browser and are not uploaded anywhere.
