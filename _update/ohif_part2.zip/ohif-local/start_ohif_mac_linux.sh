#!/usr/bin/env bash
cd "$(dirname "$0")" && python3 serve_ohif.py
