#!/usr/bin/env python3
"""Run the OHIF viewer on this computer (offline). Files you open stay in your browser; nothing is uploaded."""
import http.server, os, sys, threading, webbrowser
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "viewer")
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 3000

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **k):
        super().__init__(*a, directory=ROOT, **k)
    def end_headers(self):
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")
        self.send_header("Cross-Origin-Embedder-Policy", "require-corp")
        super().end_headers()
    def send_head(self):
        if not os.path.exists(self.translate_path(self.path.split("?")[0])):
            self.path = "/index.html"          # single-page app routes
        return super().send_head()
    def log_message(self, *a):
        pass

Handler.extensions_map.update({".js": "application/javascript", ".wasm": "application/wasm", ".mjs": "application/javascript"})
url = f"http://localhost:{PORT}/local"
srv = http.server.ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
print(f"OHIF viewer running at {url}  (press Ctrl+C to stop)")
threading.Timer(1.0, lambda: webbrowser.open(url)).start()
try:
    srv.serve_forever()
except KeyboardInterrupt:
    pass
